# Projeto de Infraestrutura de Rede IP para Campus Universitário

Este repositório documenta o planejamento e a implementação de uma rede IP confiável para um campus universitário. O projeto inclui:

- Plano de endereçamento IP por VLANs
- Comutação com segmentação por VLANs
- Roteamento estático e dinâmico via OSPF
- Servidor DHCP dedicado
- Serviços internos de DNS e Web
- Filtro de tráfego com ACLs:
  - Todas as faculdades acessam a web e podem realizar ping
  - Faculdade de Economia acessa a web, mas não realiza ping ao servidor web

🔧 Simulado em Cisco Packet Tracer com documentação técnica completa.
